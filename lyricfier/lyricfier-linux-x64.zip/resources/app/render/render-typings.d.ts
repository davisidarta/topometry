/// <reference path="../node_modules/@types/electron/index.d.ts" />
/// <reference path="../node_modules/@types/node/index.d.ts" />
/// <reference path="../node_modules/@types/vue/index.d.ts" />

declare let Notification : any;
