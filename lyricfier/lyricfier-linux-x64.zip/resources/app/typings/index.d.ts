/// <reference path="globals/electron-json-storage/index.d.ts" />
/// <reference path="globals/github-electron/index.d.ts" />
/// <reference path="globals/jquery/index.d.ts" />
/// <reference path="globals/node-4/index.d.ts" />
/// <reference path="globals/vue/index.d.ts" />
