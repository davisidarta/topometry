# The `TopOGraph` class

::: topo.models.TopOGraph
    handler: python
    selection:
      members:
        - fit
        - transform
        - spectral_layout
        - MDE
        - MAP
    rendering:
      show_root_heading: true
      show_source: true
