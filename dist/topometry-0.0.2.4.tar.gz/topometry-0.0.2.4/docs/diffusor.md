# The `Diffusor` class

::: topo.tpgraph.Diffusor
    handler: python
    selection:
      members:
        - fit
        - transform
        - spectrum_plot
        - ind_dist_grad
        - rescale
    rendering:
      show_root_heading: true
      show_source: true