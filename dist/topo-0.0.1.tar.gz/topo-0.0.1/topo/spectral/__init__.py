from .spectral import spectral_layout, component_layout, multi_component_layout
from .umap_layouts import *
